import {
	BoxBufferGeometry
} from '../../../src/Three';

export class RoundedBoxBufferGeometry extends BoxBufferGeometry {

	constructor( width?: number, height?: number, depth?: number, segments?: number, radius?: number );

}
