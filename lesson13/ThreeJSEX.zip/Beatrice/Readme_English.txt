Beatrice (Re:ZERO Starting Life in Another World) MMD
Modeled by icemega5

What I forbid:

Do not sell this model for profit. It is only use for fan-art and nothing else
Do not use this model for commercial purpose
Do not claim this model as your own

-----

Use my work responsibly. I can not be held responsible for any damages caused by this model.

Exceptions:

You may edit & take parts from Beatrice. However distribution of parts from this model is sololy forbitten.
You may not distribute the original model, but re-distribution of the edit model is okay.

Credit me as icemega5 if you are going to use this model.

You can find me at twitter
https://twitter.com/icemega5